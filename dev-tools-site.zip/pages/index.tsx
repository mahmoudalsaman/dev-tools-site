import { useState } from "react";
import { escapeHtml, diffLines } from "../lib/utils";

/**
 * الصفحة الرئيسية لتطبيق أدوات المطور.
 * تتضمن ثلاثة تبويبات: تنسيق JSON، اختبار التعبيرات النمطية، ومقارنة الاختلافات.
 */
export default function Home() {
  const [tab, setTab] = useState<"json" | "regex" | "diff">("json");
  // state الخاصة بأداة JSON
  const [jsonInput, setJsonInput] = useState("");
  const [jsonOutput, setJsonOutput] = useState("");
  const [jsonError, setJsonError] = useState("");
  // state الخاصة بأداة regex
  const [regexPattern, setRegexPattern] = useState("");
  const [regexFlags, setRegexFlags] = useState("");
  const [regexText, setRegexText] = useState("");
  const [regexMatches, setRegexMatches] = useState<RegExpMatchArray[] | null>(null);
  // state الخاصة بأداة diff
  const [diffA, setDiffA] = useState("");
  const [diffB, setDiffB] = useState("");
  const [diffResult, setDiffResult] = useState<ReturnType<typeof diffLines>>([]);

  // تنسيق JSON
  const handleJsonFormat = () => {
    try {
      const obj = JSON.parse(jsonInput);
      setJsonOutput(JSON.stringify(obj, null, 2));
      setJsonError("");
    } catch (e) {
      setJsonError((e as Error).message);
      setJsonOutput("");
    }
  };

  // اختبار التعبير النمطي
  const handleRegexTest = () => {
    try {
      const regex = new RegExp(regexPattern, regexFlags);
      const matches = Array.from(regexText.matchAll(regex));
      setRegexMatches(matches);
    } catch {
      setRegexMatches(null);
    }
  };

  // مقارنة النصين
  const handleDiff = () => {
    const result = diffLines(diffA, diffB);
    setDiffResult(result);
  };

  return (
    <div dir="rtl" lang="ar">
      <nav style={{ display: "flex", gap: "8px", marginBottom: "1rem" }}>
        <button
          className={`navlink ${tab === "json" ? "active" : ""}`}
          onClick={() => setTab("json")}
        >
          JSON
        </button>
        <button
          className={`navlink ${tab === "regex" ? "active" : ""}`}
          onClick={() => setTab("regex")}
        >
          Regex
        </button>
        <button
          className={`navlink ${tab === "diff" ? "active" : ""}`}
          onClick={() => setTab("diff")}
        >
          Diff
        </button>
      </nav>
      {tab === "json" && (
        <div>
          <textarea
            value={jsonInput}
            onChange={(e) => setJsonInput(e.target.value)}
            rows={10}
            cols={60}
            placeholder="أدخل JSON هنا"
          ></textarea>
          <div style={{ margin: "0.5rem 0" }}>
            <button onClick={handleJsonFormat}>تنسيق</button>
          </div>
          {jsonError && <div style={{ color: "red" }}>{jsonError}</div>}
          {jsonOutput && (
            <pre style={{ background: "#f5f5f5", padding: "1rem", overflowX: "auto" }}>
              {jsonOutput}
            </pre>
          )}
        </div>
      )}
      {tab === "regex" && (
        <div>
          <div style={{ marginBottom: "0.5rem" }}>
            <input
              value={regexPattern}
              onChange={(e) => setRegexPattern(e.target.value)}
              placeholder="نمط"
              style={{ marginRight: "0.5rem" }}
            />
            <input
              value={regexFlags}
              onChange={(e) => setRegexFlags(e.target.value)}
              placeholder="العلامات (مثل g,i,m)"
            />
          </div>
          <textarea
            value={regexText}
            onChange={(e) => setRegexText(e.target.value)}
            rows={10}
            cols={60}
            placeholder="النص للاختبار"
          ></textarea>
          <div style={{ margin: "0.5rem 0" }}>
            <button onClick={handleRegexTest}>اختبار</button>
          </div>
          {regexMatches && (
            <div style={{ background: "#f5f5f5", padding: "1rem", overflowX: "auto" }}>
              {regexMatches.length === 0 && <div>لا توجد نتائج</div>}
              {regexMatches.map((match, i) => (
                <div key={i}>{match[0]}</div>
              ))}
            </div>
          )}
        </div>
      )}
      {tab === "diff" && (
        <div>
          <div style={{ display: "flex", gap: "0.5rem", marginBottom: "0.5rem" }}>
            <textarea
              value={diffA}
              onChange={(e) => setDiffA(e.target.value)}
              rows={10}
              cols={45}
              placeholder="النص الأول"
            ></textarea>
            <textarea
              value={diffB}
              onChange={(e) => setDiffB(e.target.value)}
              rows={10}
              cols={45}
              placeholder="النص الثاني"
            ></textarea>
          </div>
          <div style={{ margin: "0.5rem 0" }}>
            <button onClick={handleDiff}>مقارنة</button>
          </div>
          <pre style={{ background: "#f5f5f5", padding: "1rem", overflowX: "auto" }}>
            {diffResult.map((part, index) => {
              let color: string;
              if (part.added) {
                color = "green";
              } else if (part.removed) {
                color = "red";
              } else {
                color = "black";
              }
              return (
                <span key={index} style={{ color }}>{part.value}</span>
              );
            })}
          </pre>
        </div>
      )}
      <style jsx>{`
        .navlink {
          background: none;
          border: 1px solid #ccc;
          padding: 5px 10px;
          cursor: pointer;
        }
        .navlink.active {
          background: #ddd;
        }
      `}</style>
    </div>
  );
}